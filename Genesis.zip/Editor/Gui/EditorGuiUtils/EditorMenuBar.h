﻿#pragma once
#include <string>

class EditorMenuBar
{
public:
	void AddItem(const std::string& manuPath);
};
