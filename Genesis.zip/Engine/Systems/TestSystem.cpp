﻿#include "gnspch.h"
#include "TestSystem.h"

#include <SDL2/SDL_keycode.h>

#include "../Input/InputBackend.h"
#include "../Utils/Logger.h"

void gns::TestSystem::InitSystem()
{
}

void gns::TestSystem::UpdateSystem(const float deltaTime)
{

}

void gns::TestSystem::FixedUpdate(const float fixedDeltaTime)
{

}

void gns::TestSystem::CleanupSystem()
{
}
