﻿#pragma once
#include "../ECS/SystemsManager.h"
#include "../ECS/Component.h"
#include "../ECS/Entity.h"
#include "../ECS/SystemBase.h"