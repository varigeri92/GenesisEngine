﻿#pragma once
#include "../ECS/SystemBase.h"

namespace gns
{
	class InputSystem
	{
	public:

	private:


	};
}
